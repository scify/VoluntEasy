<?php

return [
    'title' => 'VoluntEasy',
    'youHave' => 'Έχετε',
    'notifications' => 'ειδοποιήσεις',
    'allNotifications' => 'Όλες οι ειδοποιήσεις',
    'logOut' => 'Αποσύνδεση',
    'lockScreen' => 'Κλείδωμα Οθόνης',
    'profile' => 'Προφίλ',
    'tasks' => 'Οι εκκρεμότητές μου',
    'faq' => 'Βοήθεια',

];
