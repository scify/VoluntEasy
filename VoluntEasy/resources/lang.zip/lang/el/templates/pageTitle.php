<?php

return [
	'home'			=> 'Αρχική',
	'dashboard'		=> 'Dashboard', 	
];
