<?php

return [

	'home'		=> 'Αρχική',
	'loggedIn'	=> 'Είστε συνδεδεμένος!',

];
