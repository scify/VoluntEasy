<?php

return [

	'home'		=> 'Home',
	'loggedIn'	=> 'You are logged in!',

];
