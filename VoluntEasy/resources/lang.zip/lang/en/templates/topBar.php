<?php

return [
    'title' => 'Title',
    'youHave' => 'You have',
    'notifications' => 'notifications',
    'allNotifications' => 'All notifications',
    'logOut' => 'Log out',
    'lockScreen' => 'Lock screen',
    'profile' => 'Profile',
    'tasks' => 'My tasks',
    'faq' => 'FAQ',

];
