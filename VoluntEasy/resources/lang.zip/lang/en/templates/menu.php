<?php

return [

	'units' => 'Management Entities',
	'showUnits' => 'View Management Entities',
	'createUnit' => 'Create Management Entity',
	'actions' => 'Actions',
	'showActions' => 'View Actions',
	'createAction' => 'Create Action',
	'volunteers' => 'Volunteers',
	'showVolunteers' => 'View Volunteers',
	'createVolunteer' => 'Create Volunteer',
	'volunteerStatistcs' => 'Statistics',	

	'users' => 'Users',
	'createUser' => "Create User",
	'showUsers' => 'View Users',
	'tree' => 'Tree',
];
