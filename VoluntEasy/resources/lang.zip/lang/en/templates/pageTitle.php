<?php

return [
	'home'			=> 'Home',
	'dashboard'		=> 'Dashboard', 	
];
