<?php

return [

	'title'		=> 'Title',
	
];
