<?php

return [

    'choose'	=> '[- επιλέξτε -]',


];
