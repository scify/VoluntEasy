<?php

return [


    'volunteersBySex'	=> 'Εθελοντές ανά φύλο',
    'volunteersByAge'	=> 'Εθελοντές ανά ηλικιακή ομάδα',
    'volunteersByCity'	=> 'Εθελοντές ανά πόλη',
    'volunteersByEducationLevel'	=> 'Εθελοντές ανά επίπεδο εκπαίδευσης',
    'volunteersByStatus'	=> 'Καταστάσεις εθελοντών ανά μήνα',
    'volunteersByAction'	=> 'Ώρες απασχόλησης εθελοντών ανά δράση',


];
