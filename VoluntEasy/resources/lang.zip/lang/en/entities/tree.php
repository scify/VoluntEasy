<?php

return [

    'tree' => 'Δέντρο',

    'notToChooseUnit' => 'Μη Επιλέξιμη Οργανωτική Μονάδα',
    'toChooseUnit' => 'Επιλέξιμη Οργανωτική Μονάδα',
    'chosenUnitAction' => 'Επιλεγμένη Οργανωτική Μονάδα/Δράση',
    'action' => 'Δράση',



];
