<?php

return [



    'notification'	=> 'Ειδοποίηση',
    'notifications'	=> 'Ειδοποιήσεις',



    'userToUnit'	=> 'Είστε υπεύθυνος της μονάδας',
    'newVolunteer'	=> 'Ένας νέος εθελοντής ανατέθηκε στη μονάδα ',
    'actionExpired'	=> 'Η δράση :action έληξε στις :date',
    'actionExpires'	=> 'Η δράση :action λήγει στις :date',
    'volunteerContractExpired'	=> 'Η σύμβαση του εθελοντή :volunteer έληξε χτες',
    'volunteerContractExpires'	=> 'Η σύμβαση του εθελοντή :volunteer λήγει σε 6 μήνες',




];
