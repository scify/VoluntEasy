<?php

return [

	'title'		=> 'Title',
	'logIn'		=> 'Login',
	'remember'	=> 'Remember Me',
	'entrance'	=> 'Entrance',
	'forgotPass'=> 'forgot your Password?',
	'register'	=> 'Create Account',
	
];
